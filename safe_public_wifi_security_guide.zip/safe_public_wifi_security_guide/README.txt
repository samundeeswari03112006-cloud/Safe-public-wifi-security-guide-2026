# Safe Public Wi-Fi Security Guide

A beginner-friendly, responsive cybersecurity awareness website.

## Features
- Explains common public Wi-Fi threats
- Gives practical safety precautions
- Interactive personal security checklist with progress
- Three-question knowledge quiz with score
- Responsive layout for laptop and mobile

## How to run
1. Extract `safe_public_wifi_security_guide.zip`.
2. Open the folder in Visual Studio Code.
3. Open `index.html`.
4. Right-click the file and choose **Open with Live Server** (if the Live Server extension is installed), or double-click `index.html` to open it in a browser.

## Project structure
- `index.html` — complete website (HTML, CSS and JavaScript)

## Note
This is an educational awareness website. It does not connect to, scan, or test Wi-Fi networks.
